.. _ug_build_system_hooks:

Hooks: intercept the build process
==================================

.. todo::

   Document hooks.
